/**
 * Throw this error no stores are found
 */
exports.NoStoreError = class NoStoreError extends Error {}
